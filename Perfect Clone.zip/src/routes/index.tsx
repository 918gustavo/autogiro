import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import pageHtml from "@/assets/autogiro-page.html?raw";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  useEffect(() => {
    // Load the ConverteAI smartplayer SDK once (originally injected inline on the page)
    const id = "converteai-smartplayer-sdk";
    if (!document.getElementById(id)) {
      const s = document.createElement("script");
      s.id = id;
      s.src = "https://scripts.converteai.net/lib/js/smartplayer-wc/v4/sdk.js";
      s.async = true;
      document.head.appendChild(s);
    }

    // "RESULTADOS REAIS NA PRÁTICA" carousel — auto-play + arrows (identical to source)
    const slider = document.getElementById("opp-slider");
    if (!slider) return;
    const q = (sel: string) => document.querySelector<HTMLElement>(`.rm-opp-carousel ${sel}`);
    const deskNext = q(".desk-next");
    const deskPrev = q(".desk-prev");
    const mobNext = q(".mob-next");
    const mobPrev = q(".mob-prev");
    let isScrolling = false;

    const getScrollStep = () => {
      const card = slider.querySelector<HTMLElement>(".opportunity-card");
      const cardWidth = card ? card.offsetWidth : 380;
      const gap = parseFloat(window.getComputedStyle(slider).gap) || 30;
      return cardWidth + gap;
    };
    const scrollNext = () => {
      if (isScrolling) return;
      isScrolling = true;
      const step = getScrollStep();
      slider.style.scrollSnapType = "none";
      slider.scrollBy({ left: step, behavior: "smooth" });
      setTimeout(() => {
        if (slider.firstElementChild) slider.appendChild(slider.firstElementChild);
        slider.scrollBy({ left: -step, behavior: "auto" });
        slider.style.scrollSnapType = "x mandatory";
        isScrolling = false;
      }, 600);
    };
    const scrollPrev = () => {
      if (isScrolling) return;
      isScrolling = true;
      const step = getScrollStep();
      slider.style.scrollSnapType = "none";
      if (slider.lastElementChild) slider.prepend(slider.lastElementChild);
      slider.scrollBy({ left: step, behavior: "auto" });
      requestAnimationFrame(() => {
        slider.scrollBy({ left: -step, behavior: "smooth" });
        setTimeout(() => {
          slider.style.scrollSnapType = "x mandatory";
          isScrolling = false;
        }, 600);
      });
    };

    let autoPlay = window.setInterval(scrollNext, 3500);
    const resetAutoPlay = () => {
      window.clearInterval(autoPlay);
      autoPlay = window.setInterval(scrollNext, 3500);
    };
    const onNext = () => { scrollNext(); resetAutoPlay(); };
    const onPrev = () => { scrollPrev(); resetAutoPlay(); };
    deskNext?.addEventListener("click", onNext);
    deskPrev?.addEventListener("click", onPrev);
    mobNext?.addEventListener("click", onNext);
    mobPrev?.addEventListener("click", onPrev);

    return () => {
      window.clearInterval(autoPlay);
      deskNext?.removeEventListener("click", onNext);
      deskPrev?.removeEventListener("click", onPrev);
      mobNext?.removeEventListener("click", onNext);
      mobPrev?.removeEventListener("click", onPrev);
    };
  }, []);

  return <div dangerouslySetInnerHTML={{ __html: pageHtml }} />;
}
